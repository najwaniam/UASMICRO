#define BLYNK_TEMPLATE_ID "TMPL6Y2R2nho6"
#define BLYNK_TEMPLATE_NAME "Pendeteksi Hujan Dan Air"
#define BLYNK_AUTH_TOKEN "JXzcNnaoogsCixKoARYDyXhEegYgVM0a"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <BlynkSimpleEsp32.h>

#include <DHT.h>

#include <UniversalTelegramBot.h>
#include <ArduinoJson.h>

//==================================================
// WIFI
//==================================================

char ssid[] = "Griya_Kost_Raihan";
char pass[] = "bu_fitri11";

//==================================================
// TELEGRAM
//==================================================

#define BOT_TOKEN "8954590925:AAGoMfVBcs6Cjp-ba-vjc810gHuWmu99EYQ"
#define CHAT_ID "6034178150"

WiFiClientSecure client;
UniversalTelegramBot bot(BOT_TOKEN, client);

//==================================================
// PIN ESP32
//==================================================

#define DHTPIN 4
#define DHTTYPE DHT22

#define RAIN_SENSOR_PIN 34

#define LED_HIJAU 26
#define LED_MERAH 27
#define BUZZER_PIN 25

//==================================================
// DHT
//==================================================

DHT dht(DHTPIN, DHTTYPE);

//==================================================
// BLYNK TIMER
//==================================================

BlynkTimer timer;

//==================================================
// KALIBRASI SENSOR HUJAN
//==================================================

int ADC_DRY = 0;
int ADC_WET = 2500;

//==================================================
// MODE MANUAL
//==================================================

bool manualMode = false;

int ledHijauManual = 0;
int ledMerahManual = 0;
int buzzerManual = 0;

//==================================================
// STATUS
//==================================================

String currentStatus = "NORMAL";
String lastStatus = "";

//==================================================
// BLYNK CONTROL
//==================================================

BLYNK_WRITE(V4)
{
  ledHijauManual = param.asInt();
}

BLYNK_WRITE(V5)
{
  ledMerahManual = param.asInt();
}

BLYNK_WRITE(V6)
{
  buzzerManual = param.asInt();
}

BLYNK_WRITE(V7)
{
  manualMode = param.asInt();
}

//==================================================
// TELEGRAM
//==================================================

void sendTelegram(String text)
{
  bot.sendMessage(CHAT_ID, text, "");
}

//==================================================
// NOTIFIKASI STATUS
//==================================================

void sendStatusNotification(float suhu,
                            float humidity,
                            int rainPercent)
{
  if (currentStatus == lastStatus)
    return;

  lastStatus = currentStatus;

  if (currentStatus == "POTENSI HUJAN")
  {
    String msg =
      "🌥 POTENSI HUJAN TERDETEKSI\n\n"
      "🌡 Suhu : " + String(suhu, 1) + " °C\n"
      "💧 Kelembapan : " + String(humidity, 1) + "%";

    sendTelegram(msg);
  }

  else if (currentStatus == "HUJAN TERDETEKSI")
  {
    String msg =
      "🌧 HUJAN TERDETEKSI\n\n"
      "Rain Sensor : " +
      String(rainPercent) + "%";

    sendTelegram(msg);
  }

  else if (currentStatus == "HUJAN DERAS")
  {
    String msg =
      "🌧🌧 HUJAN DERAS TERDETEKSI\n\n"
      "Rain Sensor : " +
      String(rainPercent) + "%";

    sendTelegram(msg);
  }

  else if (currentStatus == "NORMAL")
  {
    sendTelegram("✅ Kondisi kembali NORMAL");
  }
}

//==================================================
// SENSOR
//==================================================

void readSensor()
{
  float humidity = dht.readHumidity();
  float suhu = dht.readTemperature();

  if (isnan(humidity) || isnan(suhu))
  {
    Serial.println("DHT22 Error");
    return;
  }

  //-----------------------------------------
  // RAIN SENSOR
  //-----------------------------------------

  int adcValue = analogRead(RAIN_SENSOR_PIN);

  int rainPercent = map(
                      adcValue,
                      ADC_DRY,
                      ADC_WET,
                      0,
                      100);

  rainPercent = constrain(
                  rainPercent,
                  0,
                  100);

  //-----------------------------------------
  // STATUS
  //-----------------------------------------

  if (rainPercent >= 70)
  {
    currentStatus = "HUJAN DERAS";
  }
  else if (rainPercent >= 20)
  {
    currentStatus = "HUJAN TERDETEKSI";
  }
  else if (humidity >= 80)
  {
    currentStatus = "POTENSI HUJAN";
  }
  else
  {
    currentStatus = "NORMAL";
  }

  //-----------------------------------------
  // MODE OTOMATIS
  //-----------------------------------------

  if (!manualMode)
  {
    if (currentStatus == "NORMAL")
    {
      digitalWrite(LED_HIJAU, HIGH);
      digitalWrite(LED_MERAH, LOW);
      digitalWrite(BUZZER_PIN, LOW);
    }

    else if (currentStatus == "POTENSI HUJAN")
    {
      digitalWrite(LED_HIJAU, LOW);
      digitalWrite(LED_MERAH, HIGH);

      digitalWrite(BUZZER_PIN, HIGH);
      delay(500);
      digitalWrite(BUZZER_PIN, LOW);
    }

    else if (currentStatus == "HUJAN TERDETEKSI")
    {
      digitalWrite(LED_HIJAU, LOW);
      digitalWrite(LED_MERAH, HIGH);
      digitalWrite(BUZZER_PIN, HIGH);
    }

    else if (currentStatus == "HUJAN DERAS")
    {
      digitalWrite(LED_HIJAU, LOW);
      digitalWrite(LED_MERAH, HIGH);
      digitalWrite(BUZZER_PIN, HIGH);
    }
  }

  //-----------------------------------------
  // MODE MANUAL
  //-----------------------------------------

  else
  {
    digitalWrite(
      LED_HIJAU,
      ledHijauManual);

    digitalWrite(
      LED_MERAH,
      ledMerahManual);

    digitalWrite(
      BUZZER_PIN,
      buzzerManual);
  }

  //-----------------------------------------
  // BLYNK
  //-----------------------------------------

  Blynk.virtualWrite(V0, suhu);
  Blynk.virtualWrite(V1, humidity);
  Blynk.virtualWrite(V2, rainPercent);
  Blynk.virtualWrite(V3, currentStatus);

  //-----------------------------------------
  // TELEGRAM
  //-----------------------------------------

  sendStatusNotification(
    suhu,
    humidity,
    rainPercent);

  //-----------------------------------------
  // SERIAL MONITOR
  //-----------------------------------------

  Serial.println("================================");

  Serial.print("Suhu : ");
  Serial.println(suhu);

  Serial.print("Kelembapan : ");
  Serial.println(humidity);

  Serial.print("ADC Rain : ");
  Serial.println(adcValue);

  Serial.print("Rain % : ");
  Serial.println(rainPercent);

  Serial.print("Status : ");
  Serial.println(currentStatus);
}

//==================================================
// SETUP
//==================================================

void setup()
{
  Serial.begin(115200);

  pinMode(LED_HIJAU, OUTPUT);
  pinMode(LED_MERAH, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_HIJAU, LOW);
  digitalWrite(LED_MERAH, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  dht.begin();

  client.setInsecure();

  Blynk.begin(
    BLYNK_AUTH_TOKEN,
    ssid,
    pass);

  sendTelegram(
    "✅ ESP32 Online\nPrototype Pendeteksi Hujan Aktif");

  timer.setInterval(
    2000L,
    readSensor);
}

//==================================================
// LOOP
//==================================================

void loop()
{
  Blynk.run();
  timer.run();
}